<div class="eltdf-register-notice">
	<h5 class="eltdf-register-notice-title"><?php echo esc_html($message); ?></h5>
	<a href="#" class="eltdf-login-action-btn" data-el="#eltdf-login-content" data-title="<?php esc_attr_e('Login', 'academist-membership'); ?>"><?php esc_html_e('Login', 'academist-membership'); ?></a>
</div>