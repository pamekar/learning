<?php

define( 'ACADEMIST_MEMBERSHIP_VERSION', '1.0' );
define( 'ACADEMIST_MEMBERSHIP_ABS_PATH', dirname( __FILE__ ) );
define( 'ACADEMIST_MEMBERSHIP_REL_PATH', dirname( plugin_basename( __FILE__ ) ) );
define( 'ACADEMIST_MEMBERSHIP_URL_PATH', plugin_dir_url( __FILE__ ) );
define( 'ACADEMIST_MEMBERSHIP_SHORTCODES_PATH', ACADEMIST_MEMBERSHIP_ABS_PATH . '/modules/shortcodes' );