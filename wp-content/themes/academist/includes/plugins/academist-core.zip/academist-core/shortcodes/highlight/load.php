<?php

include_once ACADEMIST_CORE_SHORTCODES_PATH . '/highlight/functions.php';
include_once ACADEMIST_CORE_SHORTCODES_PATH . '/highlight/highlight.php';