<?php

include_once ACADEMIST_LMS_ABS_PATH . '/widgets/course-categories-widget/functions.php';
include_once ACADEMIST_LMS_ABS_PATH . '/widgets/course-categories-widget/course-categories.php';