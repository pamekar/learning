<?php

include_once ACADEMIST_LMS_CPT_PATH . '/course/course-register.php';
include_once ACADEMIST_LMS_CPT_PATH . '/course/helper-functions.php';
include_once ACADEMIST_LMS_CPT_PATH . '/course/profile/profile-functions.php';