<div class="eltdf-quiz-active-wrapper">
	<div class="eltdf-quiz-title-wrapper">
		<?php academist_lms_get_cpt_single_module_template_part( 'single/parts/title', 'quiz', '', $params ); ?>
	</div>
	<div class="eltdf-quiz-info-top-wrapper">
		<?php academist_lms_get_cpt_single_module_template_part( 'single/parts/info-top', 'quiz', 'active', $params ); ?>
	</div>
	<div class="eltdf-quiz-question-wrapper">
		<?php academist_lms_get_cpt_single_module_template_part( 'single/layout-collections/default', 'question', '', $params ); ?>
	</div>
</div>