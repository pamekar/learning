<?php

if ( academist_elated_show_comments() ) {
	comments_template( '', true );
}