<?php if ( $query_results->max_num_pages > 1 ) { ?>
	<div class="eltdf-cl-loading">
		<div class="eltdf-cl-loading-bounce1"></div>
		<div class="eltdf-cl-loading-bounce2"></div>
		<div class="eltdf-cl-loading-bounce3"></div>
	</div>
<?php }