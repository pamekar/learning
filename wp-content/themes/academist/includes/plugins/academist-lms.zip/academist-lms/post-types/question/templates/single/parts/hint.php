<div class="eltdf-question-hint-holder">
    <span class="eltdf-hint-value">
        <?php echo esc_html( $hint_value ); ?>
    </span>
</div>