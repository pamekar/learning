<div class="eltdf-instructor-image">
	<?php the_post_thumbnail(); ?>
</div>