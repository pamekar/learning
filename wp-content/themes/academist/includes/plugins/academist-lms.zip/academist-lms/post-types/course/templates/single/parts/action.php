<div class="eltdf-course-action">
	<?php academist_lms_get_buy_form(); ?>
</div>